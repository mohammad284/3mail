<?php

namespace App\Http\Controllers;
   use Illuminate\Support\Facades\Storage;
   use Illuminate\Http\Request;
   use App\Slider;
   use App\Category;
   use App\Item;
   use App\Brand;
   use App\City;
   use App\CityImage;
   use App\CategoryItem;
   use App\GoogleMaps;
   use Mail;
   use App\User;
   use Illuminate\Support\Facades\Auth;
   use App\QRCoode;
   use Image;
   use File;
   use App\Client;
   use App\Worktime;


class IndexController extends Controller {
    
   public function index() {
        $slides = Slider::all();
        $cities = City::all();
        $categories_item = Category::orderBy('id','ASC')->take(10)->get();
        $items = Item::orderBy('id','DESC')->take(16)->get();
        $categories = Category::all();
        $new_items = Item::orderBy('created_at','DESC')->take(8)->get();
        $top_rates = Item::orderBy('created_at','ASC')->take(8)->get();
       // $sale_items = Item::whereNotNull('new_price')->take(8)->get();
       // $brands = Brand::all();
        return view('front_views.index',compact('slides','categories','items','categories_item','new_items','cities','top_rates'));
   }
   public function contact() {
        $slides = Slider::all();
        $categories_item = Category::orderBy('id','DESC')->take(10)->get();
        $items = Item::orderBy('id','DESC')->take(16)->get();
        $categories = Category::all();
        return view('front_views.contact',compact('slides','categories','items','categories_item'));

   }
    
    // send email
   public function sendContact(Request $request) {
      $data = array('name'=> $request->name, 'email' => $request->email, 'subject' => $request->subject, 'message_txt' =>$request->message );

      Mail::send('front_views.mail', $data, function($message) use ($data) {
         $message->to('info@happytoyeg.com', 'Message from website')->subject
            ($data['subject']);
         $message->from($data['email'], $data['name']);
      });
      
      echo "شكرا لك...تم إرسال رسالتك بنجاح... سنتواصل معك بأقرب وقت ممكن";
   }
   ########################### cities ###############
   public function All_cities(){
      $cities = City::all();
      return view('front_views.all_cities',compact('cities'));
   }
   
   public function city_front($id){
      $cities = City::all();
      $city = City::where('id',$id)->first();
      $categories = Category::all();
      return view('front_views.city',compact('city','categories','cities'));
   }

   public function Place_Details($id){
      if (Auth::user()){
         $workTime = Worktime::where('item_id',$id)->get();
         $user = User::find (Auth::user()->id);
         $categories = Category::all();
         $cities = City::all();
         $item = Item::where('id',$id)->first();
         $city = City::where('id',$item->city_id)->first();
         $client = Client::where('user_id',$user->id)->where('item_id',$item->id)->first();
         if ($client == NULL){
            $status = 0;
            return view('front_views.Place_Details',compact('item','city','cities','categories','user','status','workTime'));
         }else
         $status = 1;
         return view('front_views.Place_Details',compact('item','city','cities','categories','user','client','status','workTime'));
      }
      $categories = Category::all();
      $cities = City::all();
      $workTime = Worktime::where('item_id',$id)->get();
      $item = Item::where('id',$id)->first();
      $city = City::where('id',$item->city_id)->first();
      return view('front_views.Place_Details',compact('item','city','cities','categories','workTime'));
   }
   //search
   public function search(){
         $categories = Category::all();
         $cities = City::all();
         $search_text = $_GET ['search'];
         $search_item = [];
         $result_city = City::whereTranslationLike ('name','%'.$search_text.'%')->get();
            if(count($result_city) > 0){
               $items_city = new Item;
                  foreach ($result_city as $city){
                        $items_city = Item::where('city_id',$city->id)->get();
                  }
                  foreach ($items_city as $item) {
                     array_push($search_item,$item);
                  }
            }
         $result_cat = Category::whereTranslationLike('name','%'.$search_text.'%')->get();
            if(count($result_cat) > 0){
               $items_cat = new CategoryItem;
               $items = new Item;
                  foreach ($result_cat as $category){
                     $items_cat = CategoryItem::where('category_id',$category->id)->get();
                  }
                  foreach ($items_cat as $item_cat) {
                     $items = Item::where('id',$item_cat->item_id)->get();
                  }
                  foreach ($items as $item) {
                     array_push($search_item,$item);
                  }
            }
      
         $result_item = Item::whereTranslationLike ('name','%'.$search_text.'%')->get();
            if(count($result_item) > 0){
               foreach ($result_item as $item){
                  array_push($search_item,$item);
               }
            }

      return view('front_views.result',compact('search_item','categories','cities'));

   }
   //top rate
   public function topRated(){
      $results = Item::orderBy('rating', 'DESC')->take(10)->get();
      return response()->json($results);
  }

}