<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Slider;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use App\Category;
use App\Item;
use App\Brand;
use App\City;
use Image;
use App\ItemImage;
use App\CityImage;
use App\CategoryItem;
use App\User;
use App\Client;
use App\Offer;
use Illuminate\Support\Facades\Storage;


class VendorController extends Controller
{
    public function dashboard(){
        $cities = City::all();
        $categories = Category::all();
     return view('vendor.vendor',compact('cities','categories'));
    }

    public function MyProfile(){
        $cities = City::all();
        $categories = Category::all();
        $user = User::find (Auth::user()->id);
        return view('vendor.MyProfile',compact('categories','cities'));
    }

    public function myplace(){
        $cities     = City::all();
        $user       = User::find (Auth::user()->id);
        $categories = Category::all();
        $items      = Item::where('vendor_id',$user->id)->get();
        if ($user->cancel_account == 1){
            
            return view('vendor.cansel',compact('user','items','categories','cities'));
        }
        return view('vendor.myplace',compact('user','items','categories','cities'));
    }

    public function editeplace($id){
        $item            = Item::where('id',$id)->first();
        $categories      = Category::all();
        $item_id         = $item->id;
        $item_categories = CategoryItem::where('item_id',$item_id)->get();
        $cities          = City::all();
        return view('vendor.update',compact('item','item_categories','categories','cities'));
    }

    public function update(Request $request)
     {
        $user = User::find (Auth::user()->id);
        dd($request);
        $data = [
            'name'         => $request['name'],
            'email'        => $request['email'],
            'user_type'    =>$request['user_type'],
            'phone_number' =>$request['phone_number'],
            'address'      =>$request['address'],
            'place_name'   =>$request['place_name'],
            'password'     => Hash::make($request['password']),
        ];
        $user->update($data);
        return redirect()->back()->with('message','تم تعديل معلومات الحساب بنجاح');
    }

    public function newplace(){
        $user = User::find (Auth::user()->id);
        $categories = Category::all();
        $cities = City::all();
        if ($user->cancel_account == 1){
            return view('vendor.cansel',compact('categories','cities'));
        }
        return view('vendor.addnewplace',compact('categories','cities'));
    }

    public function updateprofile(Request $request){
       
        $user = User::find (Auth::user()->id);
        

          if($request['user_type'] == 'users'){
            $request['user_type'] = 'users';
            $request['type'] = 0;
            $request['vendor_request'] = 0;
            $request['cancel_account'] = 0;
        }
        if($request ['user_type'] == 'vendor'){
            $request['type'] = 0;
            $request['vendor_request'] = 1 ;
            $request['cancel_account'] = 0;
        }

        if($request->img){

            $image=$request->img;

            $input['img'] = $image->getClientOriginalName();
            $path = 'images/city/';
            $destinationPath = 'images/city';

            $img = Image::make($image->getRealPath());
            $img->resize(500, 500, function ($constraint) {
                $constraint->aspectRatio();
            })->save($destinationPath.'/'.time().$input['img']);
            $name = $path.time().$input['img'];
          $data['image'] =  $name;          
        }
        $data = [
            'name' => $request->name,
            'email' => $request->email,
            'user_type' => $request->user_type,
            'phone_number' => $request->phone_number,
            'password' => $request->_token,
            'type' => 0,
            'vendor_request' => 0,
            'cancel_account' => 0,
            'country' => $request->country,
            'image' => $request->image,
        ];

        $user->update($data);
        return redirect()->back()->with('message','تم تعديل البيانات بنجاح');

    }


    public function addnewplace(Request $request){
        $user = User::find (Auth::user()->id);
        
        $request->validate([
            'item_title_ar'   => 'required',
            'item_desc_ar'    => 'required',
            'item_address_ar' => 'required',
            'item_phone'      => 'required',
            'item_city'       => 'required',
            'img'             => 'required',
            'category'        => 'required',
            'longitude'       => 'required | numeric |min:0|not_in:0', 
            'latitude'        => 'required | numeric |min:0|not_in:0', 
        ],
        [
            'item_title_ar.required'   => 'هذا الحقل مطلوب',
            'item_desc_ar.required'    => 'هذا الحقل مطلوب',
            'item_address_ar.required' => 'هذا الحقل مطلوب',
            'item_phone.required'      => 'هذا الحقل مطلوب',
            'item_city.required'       => 'هذا الحقل مطلوب',
            'img.required'             => 'هذا الحقل مطلوب',
            'category'                 => 'هذا الحقل مطلوب'
        ]);
        
        $meta_title_ar          =  $request -> meta_title_ar;
        $meta_title_en          =  $request -> meta_title_en;
        $meta_keywards_ar       =  $request -> meta_keywards_ar;
        $meta_keywards_en       =  $request -> meta_keywards_en;
        $meta_Discription_ar    =  $request -> meta_Discription_ar;
        $meta_Discription_en    =  $request -> meta_Discription_en;

        $data = [
            'city_id'           => $request -> item_city,
            'phone_number'      => $request -> item_phone,
            'longitude'         => $request -> longitude,
            'latitude'          => $request -> latitude,
            'item_states'       => $request -> item_states,
            'reservation_phone' => $request -> reservation_phone,
            'whatsapp_phone'    => $request -> whatsapp_phone,
            'vendor_id'         => $user    -> id,
            'imaging_type'      => $request -> imaging_type,
            'link'              => $request -> link,

            'ar' => [
                'name'             => $request -> item_title_ar,
                'description'      => $request -> item_desc_ar,
                'address'          => $request -> item_address_ar,
                'meta_title'       => $request -> meta_title_ar,
                'meta_keywards'    => $request -> meta_keywards_ar,
                'meta_Discription' => $request -> meta_Discription_ar,

            ],
            'en' => [
                'name'             => $request -> item_title_en,
                'description'      => $request -> item_desc_en,
                'address'          => $request -> item_address_en,
                'meta_title'       => $request -> meta_title_en,
                'meta_keywards'    => $request -> meta_keywards_en,
                'meta_Discription' => $request -> meta_Discription_en,
            ]
        ];
      
       // dd($data);
        $item = Item::create($data);
        $item_categories = $request->category;
        if(!$item_categories == NULL) {
            foreach($item_categories as $cat) {
                CategoryItem::insert( [
                    'category_id'=>  $cat,
                    'item_id'=> $item->id
                ]);
            }
        } 
        $image = \QrCode::format('png')
        ->size(200)->errorCorrection('H')
        ->generate($item->id);
        $output_file = '/images/items/' .$item->id. '.png';
        $file = Storage::disk('local')->put($output_file, $image);
        $item->qrcode_image = 'storage'.$output_file;
        $item->save();
        if($request->file('img')){
            $path = 'images/items/'.$item->id.'/';
            if(!(\File::exists($path))){
                \File::makeDirectory($path);
            } 
            $files=$request->file('img');
            foreach($files as $file) {
 
                $input['img'] = $file->getClientOriginalName();
                $destinationPath = 'images/items/';
                
                $img = Image::make($file->getRealPath());
                $img->resize(800, 750, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($path.$input['img']);
                $name = $path.$input['img'];
                ItemImage::insert( [
                    'img'=>  $name,
                    'item_id'=> $item->id
                ]);
            }
        }
        return redirect()->back();
    }

    
    public function updateplace(Request $request, $id) {
        $user = User::find (Auth::user()->id);
        $item = Item::where('id',$id)->first();
        $item_id = $item->id;
        $item_categories = CategoryItem::where('item_id',$item_id)->delete();
        $request->validate([
            'item_title_ar' => 'required',
            'item_title_en' => 'required',
            'item_desc_ar' => 'required',
            'item_desc_en' => 'required',
            'item_address_ar' => 'required',
            'item_address_en' => 'required',
            'item_phone' => 'required',
            'item_city' => 'required',
            'category' => 'required',
            'longitude' => 'required',
            'latitude' => 'required',
            
        ],
        [
            'item_title_ar.required' => 'هذا الحقل مطلوب',
            'item_title_en.required' => 'هذا الحقل مطلوب',
            'item_desc_ar.required' => 'هذا الحقل مطلوب',
            'item_desc_en.required' => 'هذا الحقل مطلوب',
            'item_address_ar.required' => 'هذا الحقل مطلوب',
            'item_address_en.required' => 'هذا الحقل مطلوب',
            'item_phone.required' => 'هذا الحقل مطلوب',
            'item_city.required' => 'هذا الحقل مطلوب',
            'category' => 'هذا الحقل مطلوب'
        ]);
        
        $data = [
            'link' => $request->link,
            'phone_number' => $request->item_phone,
            'reservation_phone' => $request->reservation_phone,
            'whatsapp_phone' => $request->whatsapp_phone,
            'city_id' => $request->item_city,
            'longitude' => $request->longitude,
            'latitude' => $request->latitude,
            'item_states' => $request->item_states,
            'vendor_id' => $user->id,

            'ar' => [
                'name' => $request->item_title_ar,
                'description' => $request->item_desc_ar,
                'address' => $request->item_address_ar
            ],
            'en' => [
                'name' => $request->item_title_en,
                'description' => $request->item_desc_en,
                'address' => $request->item_address_en
            ]
        ];

        $item->update($data);

        $item_categories = $request->category;
        if($item_categories != NULL) {
            foreach($item_categories as $cat) {
                CategoryItem::insert( [
                    'category_id'=>  $cat,
                    'item_id'=> $item->id
                ]);
            }
        } 

        if($request->file('img')){
            $path = 'images/items/'.$item->id.'/';
            $files=$request->file('img');
            foreach($files as $file) {
                $input['img'] = $file->getClientOriginalName();
          
                $img = Image::make($file->getRealPath());
                $img->resize(800, 750, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($path.$input['img']);
                $name = $path.$input['img'];
                ItemImage::insert( [
                    'img'=>  $name,
                    'item_id'=> $item->id
                ]);
            }
        }

        return redirect()->back()->with('message','تم تعديل بيانات المكان بنجاح');
    }

    public function myClients($id){
        $categories = Category::all();
        $user = User::find (Auth::user()->id);
        $cities = City::all();
        $clients = Client::where('item_id',$id)->get();
        $my_clients = [];
        foreach($clients as $client){
            $users = User::where('id',$client->user_id)->first();
            array_push($my_clients,$users);
        }
        return view('vendor.my-clients', compact ('cities','user','categories','clients','my_clients'));
    }
    
    public function offers(Request $request){
        $item = Item::where('id',$request->item_id)->first();
        $data =[
            'user_id'   => $request -> user_id,
            'item_name' => $item    -> name,
            'offers'    => $request -> offers,
        ];
        $data = Offer::create($data);
        return redirect()->back();
    }

    public function myOffers(){
        $categories = Category::all();
        $cities     = City::all();
        $user       = User::find (Auth::user()->id);
        $to         = date('2925-09-12');
        $from       = Carbon::now()->toDateTimeString();
        $offers     = Offer::whereBetween('expiry_date', [$from, $to])->where('user_id',$user->id)->get();
        return view('vendor.my-offers',compact('user','offers','categories','cities'));

    }
}