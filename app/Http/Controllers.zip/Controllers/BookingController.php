<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Slider;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use App\Category;
use App\Item;
use App\City;
use App\CategoryItem;
use App\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;


class BookingController extends Controller
{

    public function bookview(){
        $cities = City::all();
        $categories = Category::all();
     return view('booking',compact('cities','categories'));
    }

    public function Reservation(Request $request){
        $cities = City::all();
        $categories = Category::all();
    }

    public function index()
    {
    	$response = Http::get('https://hackthestuff.com');
  
    	return $jsonData = $response->json();
      	
     	//dd($jsonData);
    }

}