<?php
namespace App\Http\Controllers\API;
    use Illuminate\Support\Facades\Storage;
    use App\Http\Controllers\Controller;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Validator;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\Hash;
    use App\City;
    use App\Category;
    use App\Item;
    use App\User;
    use App\CategoryItem;
    use App\ItemImage;
    use App\Client;
    use Illuminate\Support\Facades\Http;
    use SimpleSoftwareIO\QrCode\Facades\QrCode;
    use Image;
    use App\Offer;
    use Carbon\Carbon;
    use App\Worktime;
    use App\AnimatedTicker;

class InfoController extends Controller
{

    // Get All Cities
    public function cities(){
        $cities = City::all();
       // return response()->json($cities,);
        return response()->json([
            'cities'=>$cities,
            'key' =>'AIzaSyB0yShT09CRrUR1MeSKYdsmvtXgBbIqV80',
        ]);
    }

    // get city by id
    public function cityid($id){
        $items = Item::where('city_id',$id)->get();
        $items_array = [];
        foreach ($items as $item) {
            $itemimage=ItemImage::where('item_id',$item->id)->get();
            $final_item = array('place_data'=>$item,'place_image'=>$itemimage);
            array_push($items_array,$final_item);
        }
         return response()->json($items_array);
    }
        
    public function items(){
        $items = Item::all();
        $items_array = [];
        foreach ($items as $item) {
            $itemimage=ItemImage::where('item_id',$item->id)->get();
            $final_item = array('place_data'=>$item,'place_image'=>$itemimage);
            array_push($items_array,$final_item);
        }
        return response()->json($items_array);
    }
    
    // Get All Categories
    public function categories(){
        $categories = Category::all();
          return response()->json($categories);
        }
        // get category by city id
        public function categoryId($id){
           $city=City::where('id',$id)->first();
           $category=$city->categories;
            return response()->json($category);
    }

    //get item by city and categort id
    public function itemId($id,$cat_id){
        $item_cat = CategoryItem::where('category_id',$cat_id)->get();
        $item_city =Item::where('city_id',$id)->get();
        $items_array = [];
        foreach ($item_cat as $itemcat) {
            foreach ($item_city as $itemcity) {
                if ($itemcat->item_id == $itemcity->id ) {
                    $item = Item::where('id',$itemcity->id)->first();
                    $itemimage=ItemImage::where('item_id',$item->id)->get();
                    $final_item = array('place_data'=>$item,'place_image'=>$itemimage);
                    array_push($items_array,$final_item);
                }
            }
        }
        return response()->json($items_array);
    }

    //make search
    public function search($name){
        
        $cities = City::all();
        $search_item = [];
        $temp_array = [];

        $result_city = City::whereTranslationLike ('name','%'.$name.'%')->get();
        if(count($result_city) > 0){
            $items_city = new Item;
            foreach ($result_city as $city){
                    $items_city = Item::where('city_id',$city->id)->get();
            }
            foreach ($items_city as $item) {
                $itemimage = ItemImage::where('item_id',$item->id)->get();
                $final_item = array('place_data'=>$item,'place_image'=>$itemimage);
                array_push($search_item,$final_item);
            }
        }
        
        $result_cat = Category::whereTranslationLike('name','%'.$name.'%')->get();
        if(count($result_cat) > 0){
            $items_cat = new CategoryItem;
            $items = new Item;
            foreach ($result_cat as $category){
                $items_cat = CategoryItem::where('category_id',$category->id)->get();
            }
            foreach ($items_cat as $item_cat) {
                $items = Item::where('id',$item_cat->item_id)->get();
            }
            foreach ($items as $item) {
                $itemimage = ItemImage::where('item_id',$item->id)->get();
                $final_item = array('place_data'=>$item,'place_image'=>$itemimage);
                array_push($search_item,$final_item);
            }
        }
       
        $result_item = Item::whereTranslationLike ('name','%'.$name.'%')->get();
        if(count($result_item) > 0){
            foreach ($result_item as $item){
                $itemimage = ItemImage::where('item_id',$item->id)->get();
                $final_item = array('place_data'=>$item,'place_image'=>$itemimage);
                array_push($search_item,$final_item);
            }
        }
    
        return response()->json($search_item);
    }

    //add item from dashboard vendor
    public function addItem(Request $request){

        $request->validate([
            'item_title_ar' => 'required',
        ],
        [
            'item_title_ar.required' => 'هذا الحقل مطلوب',            
        ]);
        
        $meta_title_ar      =$request->item_title_ar;
        $meta_title_en      =$request->item_title_en;
        $meta_keywards_ar   =$request->item_title_ar;
        $meta_keywards_en   =$request->item_title_en;
        $meta_Discription_ar=$request->item_desc_ar;
        $meta_Discription_en=$request->item_desc_en;
        
        $data = [
            'city_id'              => $request->item_city,
            'phone_number'         => $request->item_phone,
            'longitude'            => $request->longitude,
            'latitude'             => $request->latitude,
            'item_states'          => '0',
            'reservation_phone'    => $request->reservation_phone,
            'whatsapp_phone'       => $request->whatsapp_phone,
            'vendor_id'            => $request->vendor_id,
            'link'                 => $request->link,
            'imaging_type'         => $request->imaging_type,
            'ar' => [
                'name'             => $request->item_title_ar,
                'address'           => $request-> item_address_ar,
                'description'      => $request->item_desc_ar,
                'meta_title'       => $meta_title_ar,
                'meta_keywards'    => $meta_keywards_ar,
                'meta_Discription' => $meta_Discription_ar,

            ],
            'en' => [
                'name'             => $request->item_title_en,
                'address'           => $request-> item_address_en,
                'description'      => $request->item_desc_en,
                'meta_title'       => $meta_title_en,
                'meta_keywards'    => $meta_keywards_en,
                'meta_Discription' => $meta_Discription_en,
            ]
        ];
      
        $item = Item::create($data);
        
        $item_categories = $request->category;
        
        if(!$item_categories == NULL) {
            foreach($item_categories as $cat) {
                CategoryItem::insert( [
                    'category_id'=>  $cat,
                    'item_id'=> $item->id
                ]);
            }
        } 
        $image = \QrCode::format('png')
        ->size(200)->errorCorrection('H')
        ->generate($item->id);
        $output_file = '/images/items/' .$item->id. '.png';
        $file = Storage::disk('local')->put($output_file, $image);
        $item->qrcode_image = 'storage'.$output_file;
        $item->save();
        
        if($request->file('img')){
            
            $path = 'images/items/'.$item->id.'/';
            if(!(\File::exists($path))){
                \File::makeDirectory($path);
            } 
            $files=$request->file('img');
            foreach($files as $file) {
 
                $input['img'] = $file->getClientOriginalName();
                $destinationPath = 'images/items/';
                
                $img = Image::make($file->getRealPath());
                $img->resize(800, 750, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($path.$input['img']);
                $name = $path.$input['img'];
                ItemImage::insert( [
                    'img'=>  $name,
                    'item_id'=> $item->id
                ]);
            }
        }
        return response()->json(['message' => 'تم اضافة المكان بنجاح']);
    }

    //edit item from dashboard vendor
    public function editItem($id) {
        $item = Item::where('id',$id)->first();
        $categories = Category::all();
        $item_id = $item->id;
        $item_categories = CategoryItem::where('item_id',$item_id)->get();
        $cities = City::all();
        return response()->json($item);
    }

    //update item from dashboard vendor
    public function updateItem(Request $request,$id){

        $item = Item::where('id',$id)->first();
        $item_id = $item->id;
        $item_categories = CategoryItem::where('item_id',$item_id)->delete();
        $request->validate([
            'item_title_ar'   => 'required',
        ],
        [
            'item_title_ar.required'   => 'هذا الحقل مطلوب',
        ]);
        $meta_title_ar      =$request->item_title_ar;
        $meta_title_en      =$request->item_title_en;
        $meta_keywards_ar   =$request->item_title_ar;
        $meta_keywards_en   =$request->item_title_en;
        $meta_Discription_ar=$request->item_desc_ar;
        $meta_Discription_en=$request->item_desc_en;
        
        $data = [
            'city_id'              => $request->item_city,
            'phone_number'         => $request->item_phone,
            'longitude'            => $request->longitude,
            'latitude'             => $request->latitude,
            'item_states'          => '0',
            'reservation_phone'    => $request->reservation_phone,
            'whatsapp_phone'       => $request->whatsapp_phone,
            'vendor_id'            => $request->vendor_id,
            'link'                 => $request->link,
            'imaging_type'         => $request->imaging_type,
            'ar' => [
                'name'             => $request->item_title_ar,
                'description'      => $request->item_desc_ar,
                'name'             => $request->item_title_ar,
                'address'          => $request-> item_address_ar,
                'description'      => $request->item_desc_ar,
                'meta_title'       => $meta_title_ar,
                'meta_keywards'    => $meta_keywards_ar,
                'meta_Discription' => $meta_Discription_ar,

            ],
            'en' => [
                'name'             => $request->item_title_en,
                'address'           => $request-> item_address_en,
                'description'      => $request->item_desc_en,
                'meta_title'       => $meta_title_en,
                'meta_keywards'    => $meta_keywards_en,
                'meta_Discription' => $meta_Discription_en,
            ]
        ];

        $item->update($data);

        $item_categories = $request->category;
        if($item_categories != NULL) {
            foreach($item_categories as $cat) {
                CategoryItem::insert( [
                    'category_id'=>  $cat,
                    'item_id'=> $item->id
                ]);
            }
        } 

        if($request->file('img')){
            $path = 'images/items/'.$item->id.'/';
            $files=$request->file('img');
            foreach($files as $file) {
                $input['img'] = $file->getClientOriginalName();
          
                $img = Image::make($file->getRealPath());
                $img->resize(800, 750, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($path.$input['img']);
                $name = $path.$input['img'];
                ItemImage::insert( [
                    'img'=>  $name,
                    'item_id'=> $item->id
                ]);
            }
        }

        return response()->json(['message' => 'تم تعديل المكان بنجاح']);
    }
    
    //item from vendor id 
    public function vendorItem($id){

        $items = Item::where('vendor_id',$id)->get();
        $search_item = [];
        foreach ($items as $item){
            
            $item_image = ItemImage::where('item_id',$item->id)->get();
            $final_item = array('place_data'=>$item,'place_image'=>$item_image);
            array_push($search_item,$final_item);
        }
        return response()->json($search_item);

    }
    //make QRcode to user 
    public function QRcodee($id){
        $item = Item::find($id);
        $image = \QrCode::format('png')
        ->size(500)->errorCorrection('H')
        ->generate($item->id);
        
        return response()->json($image)->header('Content-type','image/png');
    }
    ////update user profile
    public function updateprofile(Request $request ){
       
        $user = User::where('id',$request->id)->first();
          if($request['user_type'] == 'users'){
            $request['user_type'] = 'users';
            $request['type'] = 0;
            $request['vendor_request'] = 0;
            $request['cancel_account'] = 0;
        }
        if($request ['user_type'] == 'vendor'){
            $request['type'] = 0;
            $request['vendor_request'] = 1 ;
            $request['cancel_account'] = 0;
        }

        if($request->img){

            $image=$request->img;

            $input['img'] = $image->getClientOriginalName();
            $path = 'images/city/';
            $destinationPath = 'images/city';

            $img = Image::make($image->getRealPath());
            $img->resize(500, 500, function ($constraint) {
                $constraint->aspectRatio();
            })->save($destinationPath.'/'.time().$input['img']);
            $name = $path.time().$input['img'];
          $data['image'] =  $name;          
        }
        $data = [
            'name' => $request->name,
            'email' => $request->email,
            'user_type' => $request->user_type,
            'phone_number' => $request->phone_number,
            'password' => $request->_token,
            'type' => 0,
            'vendor_request' => 0,
            'cancel_account' => 0,
            'country' => $request->country,
            'image' => $request->image,
        ];

        $user->update($data);
        return response()->json(['message' => 'تم تعديل البروفايل بنجاح']);

    }
    //show user profile
    public function MyProfile($id){
        $cities = City::all();
        $categories = Category::all();
        $user = User::find($id);
        return response()->json($user);
    }
    // add client to data base 
    public function client(Request $request){
        
        $clients = Client::where('user_id',$request ->user_id)->get();
        if ( count($clients) == 0){
            $client = new Client ;
            $client -> user_id           = $request->user_id;
            $client -> item_id           = $request->item_id;
            $client -> client_evaluation = $request->client_evaluation;
            $client -> review            = $request->review;
            $client -> count             = 1;
            $client -> client_status     = 'new';
            $client -> save();
            $avgStar = Client::where('item_id',$request->item_id)->avg('client_evaluation');
            $item = Item::where('id',$request->item_id)->first();
            $item->rating = $avgStar;
            $item->save();
            return response()->json($client);
        } else {
            $is_visited = false;
            foreach ($clients as $client) {
                if($client->item_id == $request->item_id) {
                    $is_visited = true;
                    $count =  $client -> count + 1;
                    $client -> count = $count;
                    switch ($count) {
                        case $count < 5:
                            $client->client_status = 'new';   
                            break;             
                        case $count >= 5 && $count < 10  :
                            $client ->client_status = 'silver';
                            break;                
                        case $count >= 10  &&  $count < 15  :
                            $client ->client_status = 'gold';
                            break;
                        case $count >= 15:
                            $client ->client_status = 'diamond';
                    }
                    $client -> save(); 
                    return response()->json($client); 
                } 
            }
            if(!$is_visited) {
                $client = new Client ;
                $client -> user_id           = $request->user_id;
                $client -> item_id           = $request->item_id;
                $client -> client_evaluation = $request->client_evaluation;
                $client -> review            = $request->review;
                $client -> count             = 1;
                $client -> client_status     = 'new';
                $client -> save();

                $avgStar = Client::where('item_id',$request->item_id)->avg('client_evaluation');
                $item = Item::where('id',$request->item_id)->first();
                $item->rating = $avgStar;
                $item->save();

                return response()->json($client); 
            }
        }      
                
    }

    /*public function myClients($id){
        $user = User::find (Auth::user()->id);
        $cities = City::all();
        $clients = Client::all();
        $categories = Category::all();
        foreach ($clients as $client){
            dd($clients);
            return view('vendor.my-clients', compact ('cities','user','categories','clients'));
        }
    
    }*/
    
    // return my offers
    public function myOffers($id){
        $user = User::find($id);
        $categories = Category::all();
        $cities = City::all();
        $to = date('2925-09-12');
        $from = Carbon::now()->toDateTimeString();
        $offers = Offer::whereBetween('expiry_date', [$from, $to])->where('user_id',$user->id)->get();

        return response()->json($offers);

    }

    //type of user
    public function typeUser($id){
        $user = User::find ($id);
        $items= Client::where('user_id',$id)->get();
        return response()->json($items);
    }

    //workTime Worktime
    public function AddWorkTime(Request $request){
    
        $data =[
            'item_id'   => $request->item_id,
            'saturday'  => $request->saturday,
            'sunday'    => $request->sunday,
            'monday'    => $request->monday,
            'tuesday'   => $request->tuesday,
            'wednesday' => $request->wednesday,
            'thursday'  => $request->thursday,
            'friday'    => $request->friday,
        ];
        $worktime = WorkTime::create($data);
        return response()->json($worktime);        
    }

    public function updateWorkTime(Request $request){
    
        $worktime = WorkTime::where('item_id',$request->item_id)->first();

        $data =[
            'item_id'   => $request->item_id,
            'saturday'  => $request->saturday,
            'sunday'    => $request->sunday,
            'monday'    => $request->monday,
            'tuesday'   => $request->tuesday,
            'wednesday' => $request->wednesday,
            'thursday'  => $request->thursday,
            'friday'    => $request->friday,
        ];
        $worktime->update($data);
        return response()->json($worktime);        
    }
    //top rate
    public function topRated(){
        $results = Item::orderBy('rating', 'DESC')->take(10)->get();
        return response()->json($results);
    }
    //delete item
    public function deleteItem($id){
        $item = Item::where('id',$id)->first();
        foreach($item->images as $img) {
            if(\File::exists($img->img)){
                \File::delete($img->img);
        }
        }
        $path = 'images/items/'.$item->id.'/';
        if(\File::exists($path)){
            \File::deleteDirectory($path);
        }    
        $item->delete();
        return response()->json(['message' => 'تم حذف المكان بنجاح']);
    }
    //
    public function review($id){
        
        $reviews = Client::where('item_id',$id)->get();
        $res =[];
        foreach($reviews as $review){
            $user = User::where('id',$review->user_id)->get();
            $final = array('review'=>$review,'user'=>$user);
            array_push($res,$final);
        }
        return response()->json($res);
    }
    //
    public function ratingCount($id){
        $final_count = [];
        $count_one   = Client::where('item_id',$id)->where('client_evaluation','=','1')->count();
        $count_two   = Client::where('item_id',$id)->where('client_evaluation','=','2')->count();
        $count_three = Client::where('item_id',$id)->where('client_evaluation','=','3')->count();
        $count_four  = Client::where('item_id',$id)->where('client_evaluation','=','4')->count();
        $count_five  = Client::where('item_id',$id)->where('client_evaluation','=','5')->count();
        $final = array('one'=>$count_one,'two'=>$count_two,'three'=>$count_three,'four'=>$count_four,'five'=>$count_five);
        array_push($final_count,$final);
        return response()->json($final_count);
    }

    public function animatedTicker(){
        $animatedTicker= AnimatedTicker::all();
        return response()->json($animatedTicker);
    }
}