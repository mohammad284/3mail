<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Slider;
use App\Category;
use App\Item;
use App\Brand;
use App\City;
use App\CityImage;
use App\CategoryItem;
use App\GoogleMaps;
use Mail;

class GoogleMapsController extends Controller
{
           /* public function getPlaceAutoComplete(){
            $d['b'] =   \GoogleMaps::load('directions')
            ->setParam([
               'origin'          => 'place_id:ChIJ685WIFYViEgRHlHvBbiD5nE', 
               'destination'     => 'place_id:ChIJA01I-8YVhkgRGJb0fW4UX7Y', 
               'mode'            => 'driving',
               'waypoints'       => 'Charlestown,MA|Lexington,MA',// can also be given as an array ['Charlestown,MA','Lexington,MA']
               'alternatives'    => true,
               'avoid'           => 'ferries',
               'units'           => 'metric',
               'region'          => 'GB',
               'departure_time'  => 'now',
            ])
         ->getResponseByKey('routes.legs.steps.html_instructions');
         dd($d);
         return view('welcome',compact('d'));
         } 
         */
      
      
         // بتجيب معلومات مدينة دمشق
         /* public function getPlaceAutoComplete(){
            $response = \GoogleMaps::load('directions')
            ->setParam([
                'origin'          => 'place_id:ChIJ685WIFYViEgRHlHvBbiD5nE',
                'destination'     => 'place_id:ChIJA01I-8YVhkgRGJb0fW4UX7Y',
            ])
           ->get();
         dd($response);
         
         return view('welcome',compact('response'));
         
      }
   //الطريق بين مدينتين
     /* public function getPlaceAutoComplete(){
         $d['b'] =   \GoogleMaps::load('directions')
         ->setParam([
            'origin'          => 'place_id:ChIJ685WIFYViEgRHlHvBbiD5nE', 
            'destination'     => 'place_id:ChIJp8Y8QdzmGBUR8pTj0etmn2s',
            'mode'            => 'driving',
         ])->get();
         
         dd($d);
   }
  /* public function getPlaceAutoComplete(){
      $response = \GoogleMaps::load('geocoding')
      ->setParamByKey('latlng', '40.714224,-73.961452')
       ->get('results.geometry.location');
   
       dd($response);
   return view('welcome',compact('response'));
   dd($response);
}*/


    public function getPlaceAutoComplete(){

        $endpoint = \GoogleMaps::load('geocoding')
        ->setParamByKey('address', 'Tartus')
        ->get('results.geometry.location');
        $location_coordinates = [];
        foreach($endpoint as $result) {
            foreach($result as $res) {
                foreach($res as $loc) {
                    $location_coordinates = $loc['location'];
                }
            }
        }
        $location_lng = $location_coordinates['lng'];
        $location_lat = $location_coordinates['lat'];
        return view('welcome' ,compact ('location_lng','location_lat'));
        }
        /*public function getPlaceAutoComplete(){
            $d =   \GoogleMaps::load('timezone')
            ->setParam([
            'location' => '39.6034810,-119.6822510',
                'timestamp' => '1331161200'
            ])
        ->get();
        
        dd($d);}*/
    public function googlee(){
        return view ('welcome');
    }
    public function getPlaceAdd(){
            
        $d =  \GoogleMaps::load('placeadd')              
                ->setParam([
                'location' => [
                    'lat' => -33.8669710,
                    'lng' => 151.1958750
                ],
                'accuracy' 	=> 0,
                "name" 		=>  "Google Shoes!",
                "phone_number" 	=>  "(02) 9374 4000",
                "address" 	=> "48 Pirrama Road, Pyrmont, NSW 2009, Australia",
                "types"    	=> ["shoe_store"], // types and not type as per docs
                "website"      	=> "http://www.google.com.au/",
                "language" 	=> "en-AU"                        
            ])
            ->get('webServices');
            dd($d);
    } 



    public function googleAutoAddress()
    {
        return view('welcome2');
    }
}
