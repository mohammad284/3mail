<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Slider;
use App\Category;
use App\Item;
use App\Brand;
use App\City;
use App\CityImage;
use App\User;
use App\GoogleMaps;

class AccountsController extends Controller
{
    public function request_accounts(){
        $users = User::all();
        return view('dashboard.Accounts',compact('users'));
    }
    public function userAccounts(){
        $users = User::all();
        return view('dashboard.approve_accounts',compact('users'));
    }
    public function cancelAccounts(){
        $users = User::all();
        return view('dashboard.cancel_accounts',compact('users'));
    }

    public function approve($id){

        $users = User::find($id);
        $users->type=1;
        $users->vendor_request=0;
        $users->cancel_account=0;
        $users->save();
        return redirect()->back();
    }
    
    public function cancel_vendor($id){
        
        $users = User::find($id);
        $users->type=0;
        $users->vendor_request=0;
        $users->cancel_account=1;
        $users->save();
        return redirect()->back();
    }
    public function active_vendor($id){
        
        $users = User::find($id);
        $users->type=1;
        $users->vendor_request=0;
        $users->cancel_account=0;
        $users->save();
        return redirect()->back();
    }



}

