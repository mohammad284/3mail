<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Support\Str;
use Illuminate\Support\Arr;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use App\Item;
use App\ItemImage;
use App\Category;
use App\CategoryItem;
use App\City;
use Image;
use File;

class ItemController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    //  ***** Admin Functions ***** //

    // Show all items
    public function admin() {
        $items = Item::orderBy('id','DESC')->paginate(15);
        return view('dashboard.item.item',compact('items'));
    }
    
    // Go to add new item page
    public function create() {
        $categories = Category::all();
        $cities = City::all();
        return view('dashboard.item.item-add',compact('categories','cities'));
    }
    
    // Add new item
    public function store(Request $request) {

        $request->validate([
            'item_title_ar'   => 'required',
            'item_desc_ar'    => 'required',
            'item_phone'      => 'required',
            'item_address_ar' => 'required',
            'item_city'       => 'required',
            'img'             => 'required',
            'category'        => 'required',
            'longitude'       => 'required',
            'latitude'        => 'required',
        ],
        [
            'item_title_ar.required'   => 'هذا الحقل مطلوب',
            'item_desc_ar.required'    => 'هذا الحقل مطلوب',
            'item_address_ar.required' => 'هذا الحقل مطلوب',
            'item_phone.required'      => 'هذا الحقل مطلوب',
            'item_city.required'       => 'هذا الحقل مطلوب',
            'img.required'             => 'هذا الحقل مطلوب',
            'category'                 => 'هذا الحقل مطلوب'
        ]);
        
        $meta_title_ar        =$request->meta_title_ar;
        $meta_title_en        =$request->meta_title_en;
        $meta_keywards_ar     =$request->meta_keywards_ar;
        $meta_keywards_en     =$request->meta_keywards_en;
        $meta_Discription_ar  =$request->meta_Discription_ar;
        $meta_Discription_en  =$request->meta_Discription_en;


        $data = [
            'item_states'           => $request -> item_states,
            'city_id'               => $request -> item_city,
            'phone_number'          => $request -> item_phone,
            'longitude'             => $request -> longitude,
            'latitude'              => $request -> latitude,
            'link'                  => $request -> link,
            'imaging_type'          => $request -> imaging_type,
            'reservation_phone'     => $request -> reservation_phone,
            'whatsapp_phone'        => $request -> whatsapp_phone,
            'ar' => [
                'name'              => $request-> item_title_ar,
                'address'           => $request-> item_address_ar,
                'description'       => $request-> item_desc_ar,
                'meta_title'        => $meta_title_ar,
                'meta_keywards'     => $meta_keywards_ar,
                'meta_Discription'  => $meta_Discription_ar,
                
            ],
            'en' => [
                'name'              => $request-> item_title_en,
                'address'           => $request-> item_address_en,
                'description'       => $request-> item_desc_en,
                'meta_title'        => $meta_title_en,
                'meta_keywards'     => $meta_keywards_en,
                'meta_Discription'  => $meta_Discription_en,
            ]
        ];

        $item = Item::create($data);
        
        $item_categories = $request->category;
        
        if(!$item_categories == NULL) {
            foreach($item_categories as $cat) {
                CategoryItem::insert( [
                    'category_id'=>  $cat,
                    'item_id'=> $item->id
                ]);
            }
        } 

        $image = \QrCode::format('png')
        ->size(200)->errorCorrection('H')
        ->generate($item->id);
        $output_file = '/images/items/' .$item->id. '.png';
        $file = Storage::disk('local')->put($output_file, $image);
        $item->qrcode_image = 'storage'.$output_file;
        $item->save();

        
        if($request->file('img')){
            $path = 'images/items/'.$item->id.'/';
            if(!(\File::exists($path))){
                \File::makeDirectory($path);
            } 
            $files=$request->file('img');
            foreach($files as $file) {
 
                $input['img'] = $file->getClientOriginalName();
                $destinationPath = 'images/items/';
                
                $img = Image::make($file->getRealPath());
                $img->resize(800, 750, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($path.$input['img']);
                $name = $path.$input['img'];
                ItemImage::insert( [
                    'img'=>  $name,
                    'item_id'=> $item->id
                ]);

            }
        }

        return redirect('/admin/items')->with('message','تم إضافة مكان جديد بنجاح');

    }
    
    // Show all items related to spicifice category
    public function show($id) {
        $category = Category::find($id);
        $items = $category->items;
        return view('dashboard.item.item-cat',compact('items'));
    }

    // Go to edit item page
    public function edit($id) {
        $item = Item::where('id',$id)->first();
        $categories = Category::all();
        $item_id = $item->id;
        $item_categories = CategoryItem::where('item_id',$item_id)->get();
        $cities = City::all();
        return view('dashboard.item.item-edit',compact('item','item_categories','categories','cities'));
    }
    
    //Update item info
    public function update(Request $request, $id) {
        
        $item = Item::where('id',$id)->first();
        $item_id = $item->id;
        $item_categories = CategoryItem::where('item_id',$item_id)->delete();
        $request->validate([
            'item_title_ar'   => 'required',
            'item_title_en'   => 'required',
            'item_desc_ar'    => 'required',
            'item_desc_en'    => 'required',
            'item_address_ar' => 'required',
            'item_address_en' => 'required',
            'item_phone'      => 'required',
            'item_city'       => 'required',
            'category'        => 'required',
            'longitude'       => 'required',
            'latitude'        => 'required',
            
        ],
        [
            'item_title_ar.required'   => 'هذا الحقل مطلوب',
            'item_title_en.required'   => 'هذا الحقل مطلوب',
            'item_desc_ar.required'    => 'هذا الحقل مطلوب',
            'item_address_ar.required' => 'هذا الحقل مطلوب',
            'item_address_en.required' => 'هذا الحقل مطلوب',
            'item_desc_en.required'    => 'هذا الحقل مطلوب',
            'item_phone.required'      => 'هذا الحقل مطلوب',
            'item_city.required'       => 'هذا الحقل مطلوب',
            'category'                 => 'هذا الحقل مطلوب',
        ]);
        
        $data = [
            'link'                  => $request->link,
            'latitude'              => $request->latitude,
            'longitude'             => $request->longitude,
            'city_id'               => $request->item_city,
            'phone_number'          => $request->item_phone,
            'item_states'           => $request->item_states,
            'imaging_type'          => $request->imaging_type,
            'whatsapp_phone'        => $request->whatsapp_phone,
            'reservation_phone'     => $request->reservation_phone,
            'ar' => [
                'description'       => $request->item_desc_ar,
                'name'              => $request->item_title_ar,
                'meta_title'        => $request->meta_title_ar,
                'address'           => $request->item_address_ar,
                'meta_keywards'     => $request->meta_keywards_ar,
                'meta_Discription'  => $request->meta_Discription_ar,
                
            ],
            'en' => [
                'description'       => $request->item_desc_en,
                'meta_title'        => $request->meta_title_en,
                'name'              => $request->item_title_en,
                'address'           => $request->item_address_en,
                'meta_keywards'     => $request->meta_keywards_en,
                'meta_Discription'  => $request->meta_Discription_en,
            ]
        ];

        $item->update($data);

        $item_categories = $request->category;
        if($item_categories != NULL) {
            foreach($item_categories as $cat) {
                CategoryItem::insert( [
                    'category_id'=>  $cat,
                    'item_id'=> $item->id
                ]);
            }
        } 

        if($request->file('img')){
            $path = 'images/items/'.$item->id.'/';
            $files=$request->file('img');
            foreach($files as $file) {
                $input['img'] = $file->getClientOriginalName();
          
                $img = Image::make($file->getRealPath());
                $img->resize(800, 750, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($path.$input['img']);
                $name = $path.$input['img'];
                ItemImage::insert( [
                    'img'=>  $name,
                    'item_id'=> $item->id
                ]);
            }
        }

        return redirect()->back()->with('message','تم تعديل بيانات المكان بنجاح');
    }

    // Delete Sub image form item
    public function imagedelete($id) {
        $img = ItemImage::where('id',$id)->first();
        $item_id = $img->item_id;
        $images = ItemImage::where('item_id',$item_id)->get();
        if (count($images) > 1) {
             $path = 'images/items/';
            if(\File::exists($img->img)){
                \File::delete($img->img);
            }
            $img->delete();
            return redirect()->back()->with('message','تم حذف الصورة بنجاح');
        } else {
            return redirect()->back()->with('message','لايمكنك حذف الصورة، يجب أن يكون للمكان صورة واحدة على الأقل');
        }
    }

    // Delete item with all images form directory
    public function destroy($id) {
        $item = Item::where('id',$id)->first();
        foreach($item->images as $img) {
            if(\File::exists($img->img)){
                \File::delete($img->img);
        }
        }
        $path = 'images/items/'.$item->id.'/';
        if(\File::exists($path)){
            \File::deleteDirectory($path);
        }    
        $item->delete();
        return redirect('/admin/items')->with('message','تم حذف بيانات المكان بنجاح');
    }

    public function requestitem(){
        $items = Item::all();
        return view('dashboard.item.item-request',compact('items'));
    }
    
    public function approve($id){
        $item = Item::find($id);
        $item->item_states=1;
        $item->save();
        return redirect()->back();
    }

    public function editRequest($id){
        $item = Item::where('id',$id)->first();
        return view('dashboard.item.edit-request',compact('item'));

    }

    public function updateRequest(Request $request ,$id){
        $item = Item::where('id',$id)->first();
        $item->link = $request->link;
        $item->save();
        return redirect()->back();

    }
}
