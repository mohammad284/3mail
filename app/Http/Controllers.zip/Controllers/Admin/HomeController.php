<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Item;
use App\City;
use App\Category;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cities = City::all();
        $items = Item::all();
        $categories = Category::all();
        $items_count = count($items);
        $city_count = count($cities);
        $cat_count = count($categories);
        return view('dashboard.index',compact('items_count','city_count','cat_count'));
    }
}