	
    		<footer id="tg-footer" class="tg-footer tg-haslayout">
			<div class="tg-fourcolumns">
				<div class="container">
					<div class="row">
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
							<div class="tg-footercolumn tg-widget tg-widgettext">
								<div class="logo"><a class="logo__link" href="index.html"><img class="logo__img" src="{{ asset('frontend_res/img/logo.png') }}" alt="Doremi"></a></div>
								<p>هذا النص هو مثال لنص يمكن أن <br> هذا النص هو مثال لنص يمكن أن <br> هذا النص هو مثال لنص يمكن أن </p>
							   
							</div>
						</div>
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
							<div class="tg-footercolumn tg-widget tg-widgetdestinations">
								<div class="tg-widgettitle">
									<h3>المدن</h3>
								</div>
								<div class="tg-widgetcontent">
                                <ul>

									</ul>
								</div>
							</div>
						</div>
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
							<div class="tg-footercolumn tg-widget tg-widgetnewsletter">
								<div class="tg-widgettitle">
									<h3>{{__('تواصل معنا')}}</h3>
								</div>
								<div class="tg-widgetcontent">
									<ul class="uk-list">
										<li> <span>{{__('البريد الالكتروني')}} </span><a href="mailto:support@domain.com">support@domain.com</a></li>
										<li> <span>{{__('الهاتف')}} </span><a href="tel:104023513690">+1 (040) 2351 3690</a></li>
									  </ul>
									  <ul class="social">
										<li><a href="#!"><i class="fab fa-twitter"></i></a></li>
										<li><a href="#!"><i class="fab fa-facebook-f"></i></a></li>
										<li><a href="#!"><i class="fab fa-youtube"></i></a></li>
										<li><a href="#!"><i class="fab fa-instagram"></i></a></li>
									  </ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!--************************************
				Footer End
		*************************************-->
	</div>

    <script src="{{ asset('auth/js/vendor/jquery-library.js') }}"></script>
	<script src="{{ asset('auth/js/vendor/bootstrap-arabic.min.js') }}"></script>
	<script src="{{ asset('auth/js/bootstrap-select.min.js') }}"></script>
    <script src="{{ asset('auth/js/jquery.mmenu.all.js') }}"></script>
    <script src="{{ asset('auth/js/jquery.vide.min.js') }}"></script>
    <script src="{{ asset('auth/js/packery.pkgd.min.js') }}"></script>
    <script src="{{ asset('auth/js/scrollbar.min.js') }}"></script>
    <script src="{{ asset('auth/js/prettyPhoto.js') }}"></script>
    <script src="{{ asset('auth/js/countdown.js') }}"></script>
    <script src="{{ asset('auth/js/parallax.js') }}"></script>
    <script src="{{ asset('auth/js/main.js') }}"></script>
</body>
</html>
